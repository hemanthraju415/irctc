package com.pennant.irctc.mvc;

public class StationModel {
	private String station_name;
	private String Station_code;

	public String getStation_name() {
		return station_name;
	}

	public void setStation_name(String station_name) {
		this.station_name = station_name;
	}

	public String getStation_code() {
		return Station_code;
	}

	public void setStation_code(String station_code) {
		Station_code = station_code;
	}

}
